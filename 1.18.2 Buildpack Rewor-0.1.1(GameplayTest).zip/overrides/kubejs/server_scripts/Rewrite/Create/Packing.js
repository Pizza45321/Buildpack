onEvent('recipes', event => {
	event.recipes.createCompacting('minecraft:gravel',"9x minecraft:flint")
	
})