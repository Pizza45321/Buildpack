onEvent('recipes', event =>{
	event.custom({
		"type": "tconstruct:melting",
		"ingredient": {
			"item": "minecraft:blaze_powder"
	},
	"result":{
		"fluid": "tconstruct:blazing_blood",
		"amount": 50
	}	
})
})