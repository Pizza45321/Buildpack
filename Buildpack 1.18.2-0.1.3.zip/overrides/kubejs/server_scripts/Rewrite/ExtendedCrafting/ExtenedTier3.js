onEvent('recipes', event =>{
event.custom({
  "type": "extendedcrafting:shaped_table",
  "pattern": [
    "ABBCBBA",
    "BDCECDB",
    "BFGHGFB",
    "CEIJIEC",
    "BFGKGFB",
    "BDCECDB",
    "ABBCBBA"
  ],
  "key": {
    "A": {
      "item": "mekanism:ingot_refined_obsidian"
    },
    "B": {
      "item": "immersiveengineering:plate_steel"
    },
    "C": {
      "item": "extendedcrafting:black_iron_slate"
    },
    "D": {
      "item": "thermal:redstone_servo"
    },
    "E": {
      "item": "create:mechanical_press"
    },
    "F": {
      "item": "immersiveengineering:component_electronic_adv"
    },
    "G": {
      "item": "thermal:rf_coil"
    },
    "H": {
      "item": "extendedcrafting:elite_catalyst"
    },
    "I": {
      "item": "extendedcrafting:elite_component"
    },
    "J": {
      "item": "thermal:machine_press"
    },
    "K": {
      "item": "extendedcrafting:frame"
    }
  },
  "result": {
    "item": "extendedcrafting:compressor"
  }
})
})