onEvent('recipes', event => {
	event.recipes.createCutting('4x mna:stone_rune_blank', 'botania:livingrock')
})



