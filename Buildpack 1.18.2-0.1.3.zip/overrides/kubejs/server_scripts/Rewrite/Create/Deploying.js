onEvent('recipes', event => {
	// event.recipes.createDeploying('output', ['input'])
})