onEvent('recipes', event => {
	event.recipes.createCompacting('minecraft:gravel',"4x minecraft:flint")
	
})