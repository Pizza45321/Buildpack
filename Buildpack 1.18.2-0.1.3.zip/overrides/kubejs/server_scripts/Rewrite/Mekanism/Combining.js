onEvent('recipes', event => {
	//event.recipes.mekanismCombining(out,bottomSlot,topSlot)
	event.recipes.mekanismCombining('extradisks:advanced_machine_casing','refinedstorage:machine_casing','rebornstorage:super_advanced_processor')
})