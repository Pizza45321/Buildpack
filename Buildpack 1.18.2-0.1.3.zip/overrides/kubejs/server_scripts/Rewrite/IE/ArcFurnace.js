onEvent('recipes', event => {
event.recipes.immersiveengineeringArcFurnace(['12x bigreactors:basic_reactorcasing'], 'thermal:machine_frame', ['4x minecraft:iron_block', '4x mekanism:block_steel','4x tconstruct:cobalt_block'])
event.recipes.immersiveengineeringArcFurnace(['12x bigreactors:basic_turbinecasing'], 'thermal:machine_frame', ['4x minecraft:copper_block', '4x mekanism:block_steel','4x tconstruct:cobalt_block'])
})